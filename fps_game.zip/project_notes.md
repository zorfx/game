Starting FPS game development project
